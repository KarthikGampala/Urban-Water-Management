# Urban-water-management-system
How to efficiently manage water in urban cities
